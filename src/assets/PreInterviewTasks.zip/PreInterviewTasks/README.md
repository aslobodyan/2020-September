Please complete the 4 included tasks and send them back once you've completed them.
If we have arranged an interview with you, please complete and return them at least 24 hours before your interview.
Take as long as you need to complete the tasks. We anticipate they should take between 1 and 2 hours, but do not worry if they take longer. Please include how long you spent when sending them back.
